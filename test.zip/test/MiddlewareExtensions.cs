﻿using Microsoft.AspNetCore.Builder;

namespace Infrastructure
{
	internal static class MiddlewareExtensions
	{
		public static IApplicationBuilder UseCustomExceptionHandler(this IApplicationBuilder builder)
		{
			return builder.UseMiddleware<ExceptionHandlerMiddleware>();
		}

		public static IApplicationBuilder UseMessageHandler(this IApplicationBuilder builder)
		{
			return builder.UseMiddleware<MessageHandlerMiddleware>();
		}
	}
}
