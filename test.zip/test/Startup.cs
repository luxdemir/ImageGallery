﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using AspNetCore.CacheOutput.Extensions;
using AspNetCore.CacheOutput.InMemory.Extensions;
using Castle.Facilities.AspNetCore;
using Castle.MicroKernel.Registration;
using Hangfire;
using Hangfire.MemoryStorage;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Negotiate;
using IWebHostEnvironment = Microsoft.AspNetCore.Hosting.IWebHostEnvironment;

namespace Api
{
    public class Startup
    {

        public Startup(IWebHostEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables();
            Configuration = builder.Build();
            HostingEnvironment = env;
        }

        public IConfiguration Configuration { get; }
        public IWebHostEnvironment HostingEnvironment { get; }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(
            IApplicationBuilder app,
            IWebHostEnvironment env,
            ILoggerFactory loggerFactory,
            IOptions<JobsConfiguration> jobsOptions,
            IHostApplicationLifetime applicationLifetime)
        {

#if DEBUG
            if (env.IsDevelopment())
            {
                //loggerFactory.AddConsole(Configuration.GetSection("Logging"));
                //loggerFactory.AddDebug();
                //app.UseDeveloperExceptionPage();
            }
#else
#endif
            if (!Directory.Exists("logs"))
                Directory.CreateDirectory("logs");

            app.UseAuthentication();
            app.UseCustomExceptionHandler();
            app.UseMessageHandler();
            app.UseCacheOutput();
            app.UseRouting();
            app.UseAuthorization();
            app.UseResponseCompression();
            app.UseStaticFiles();

            applicationLifetime.ApplicationStopping.Register(DisposeResources);

            ContainerFactory.Container.GetFacility<AspNetCoreFacility>().RegistersMiddlewareInto(app);
            ContainerFactory.Container.Register(Component.For<IHubService>().ImplementedBy<FakeHubService>().LifestyleSingleton()); // временно

            app.UseHsts();
            app.UseCors(config =>
                config.AllowAnyHeader().AllowAnyMethod().SetIsOriginAllowed((host) => true).AllowCredentials());

            app.UseHttpsRedirection();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapDefaultControllerRoute();
                endpoints.MapHub<FoldersHub>("/folders");
            });

            //if (jobsOptions.Value.Enabled)
            //{
            //	GlobalConfiguration.Configuration.UseActivator(new HangfireActivator(serviceProvider));
            //	if (env.IsDevelopment())
            //	{
            //		app.UseHangfireDashboard();
            //	}
            //	app.UseHangfireServer(new BackgroundJobServerOptions { WorkerCount = jobsOptions.Value.WorkersCount ?? Math.Min(Environment.ProcessorCount * 2, 10)});
            //}

            if (new AppSettings(Configuration, true).SwaggerUiEnabled)
            {
                app.UseOpenApi();
                // Enable middleware to serve swagger-ui (HTML, JS, CSS etc.), specifying the Swagger JSON endpoint.
                app.UseSwaggerUi3(settings =>
                {
                    //settings.DocumentPath = "/swagger/v1/swagger.json";
                    //settings.Title = "DDMWebApi V1";
                });
            }

        }

        // This method gets called by the runtime. Use this method to add services to the ContainerFactory.Container.
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            ContainerFactory.Container.AddFacility<AspNetCoreFacility>(f => f.CrossWiresInto(services));
            services.AddCors();
            services.AddAuth();
            services.AddOptions();
            services.Configure<JobsConfiguration>(Configuration.GetSection("Jobs"));
            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddHttpClient();
            services.AddInMemoryCacheOutput();
#if DEBUG
            services.AddSingleton<IHostedService, FoldersHostedService>();
#endif
            //services.AddHangfire(config =>
            //{
            //	config.UseMemoryStorage();
            //});

            services.AddSignalR()
                .AddNewtonsoftJsonProtocol(options => {
                    options.PayloadSerializerSettings.ContractResolver = new DefaultContractResolver();
                })
                .AddMessagePackProtocol();

            services.AddAntiforgery(options => options.HeaderName = "X-XSRF-TOKEN");
            services.AddResponseCompression();
            services.AddControllers(config =>
            {
                var policy = new AuthorizationPolicyBuilder()
                                 .RequireAuthenticatedUser()
                                 .Build();
                config.Filters.Add(new AuthorizeFilter(policy));
            })
                .AddNewtonsoftJson(options =>
                {
                    options.SerializerSettings.ContractResolver = new DefaultContractResolver();
                    options.SerializerSettings.Converters.Add(new ZeroYaerIsoDateTimeConverter());
                    options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
                    options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                    options.SerializerSettings.Formatting = Formatting.Indented;
                    options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Local;
                })
                .AddMvcOptions(options =>
                {
                    options.InputFormatters.OfType<NewtonsoftJsonInputFormatter>().First().SupportedMediaTypes.Add(new Microsoft.Net.Http.Headers.MediaTypeHeaderValue("text/html"));
                    //options.OutputFormatters.Add(new HtmlOutputFormatter());
                    options.AllowEmptyInputInBodyModelBinding = true;
                })
                .SetCompatibilityVersion(CompatibilityVersion.Version_3_0);

            services.AddApiVersioning(o => {
                o.ReportApiVersions = true;
                o.ApiVersionReader = new HeaderApiVersionReader("api-version");
                o.AssumeDefaultVersionWhenUnspecified = true;
                o.DefaultApiVersion = new ApiVersion(1, 0);
            });

            if (new AppSettings(Configuration, true).SwaggerUiEnabled)
            {
                services.AddSwaggerDocument();
            }
            RegisterApplicationComponents(services);

            return services.AddWindsor(ContainerFactory.Container,
                opts => opts.UseEntryAssembly(typeof(HomeController).Assembly),
                () => services.BuildServiceProvider(validateScopes: false));
        }

        private ServiceProvider RegisterApplicationComponents(IServiceCollection services)
        {
            var serviceProvider = services.BuildServiceProvider(validateScopes: false);
            ContainerFactory.Container.Register(Component.For<ILoggerFactory>().Instance(serviceProvider.GetService<ILoggerFactory>()).LifestyleSingleton());
            var appSettings = new AppSettings(Configuration);
            services.AddSingleton(appSettings);
            ContainerFactory.Container.Register(Component.For<AppSettings>().Instance(appSettings).LifestyleSingleton());
            ContainerFactory.Container.Register(Classes.FromAssembly(Assembly.GetCallingAssembly()).BasedOn<ControllerBase>().LifestyleScoped());
            ContainerFactory.Container.Register(Classes.FromAssemblyContaining(typeof(LicenseService)).Pick().LifestyleScoped().WithServiceFirstInterface());
            ContainerFactory.Container.Register(Classes.FromAssemblyContaining(typeof(IDocumentsStore)).Pick().LifestyleScoped().WithServiceFirstInterface());
            ContainerFactory.Container.Register(Component.For<IWebDavStore>().ImplementedBy<DocsVisionDiskStore>().LifestyleSingleton());
            ContainerFactory.Container.Register(Component.For<WebDavServer>().ImplementedBy<WebDavServer>().LifestyleSingleton());
            ContainerFactory.Container.Register(Component.For<IConfigurationService>().ImplementedBy(typeof(ConfigurationService)).LifestyleSingleton().Named("configurationServiceOverride").IsDefault());
            ContainerFactory.Container.Register(Component.For<IArchiveService>().ImplementedBy(typeof(ArchiveService)).LifestyleScoped().Named("caseServiceOverride").IsDefault());

            ContainerFactory.Container.Register(Component.For<IOptions<MvcNewtonsoftJsonOptions>>().LifestyleScoped());

            var configuration = ContainerFactory.Container.Resolve<IConfigurationService>();
            ContainerResolver.RegisterCacheProviders(configuration);

            var nativeServices = Classes.FromAssemblyContaining(typeof(UniversalServiceNative)).Pick().WithServiceFirstInterface().LifestyleScoped();
            if (configuration.DeepTrace)
            {
                ContainerFactory.Container.Register(Component.For<LoggingInterceptor>());
                nativeServices.Configure(x => x.Interceptors<LoggingInterceptor>());
            }

            ContainerFactory.Container.Register(nativeServices);

            ContainerFactory.Container.Register(Component.For<IStaffSearch>().ImplementedBy<Search.DocsVision.StaffSearch>().LifestyleScoped().IsDefault());
            ContainerFactory.Container.Register(Component.For<IPartnersSearch>().ImplementedBy<Search.DocsVision.PartnersSearch>().LifestyleScoped().IsDefault());

            return serviceProvider;
        }

        private void DisposeResources()
        {
            try
            {
                UserSessionPoolService.SessionPool?.Dispose();
            }
            catch (Exception e)
            {
                Log.Instance.Error(e);
            }
            DirectoryHelper.CleanupTempFolder();
        }
    }
}
