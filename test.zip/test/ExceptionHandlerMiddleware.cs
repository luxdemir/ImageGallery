﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using DocsVision.Platform.StorageServer;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace Api.Infrastructure
{
	public class ExceptionHandlerMiddleware
	{
		private readonly RequestDelegate _next;
		private readonly ILogger<ExceptionHandlerMiddleware> _logger;

		public ExceptionHandlerMiddleware(RequestDelegate next, ILogger<ExceptionHandlerMiddleware> logger)
		{
			_next = next;
			_logger = logger ?? throw new ArgumentNullException(nameof(logger));
		}

		public async Task Invoke(HttpContext context)
		{
			try
			{
				await _next.Invoke(context);
			}
			catch (Exception ex)
			{
				var statusCode = HttpStatusCode.InternalServerError;

				if (ex is UserNotFound)
				{
					statusCode = HttpStatusCode.Unauthorized;
				}			

                if (statusCode != HttpStatusCode.Unauthorized && statusCode != HttpStatusCode.BadRequest)
				{
					_logger.LogError(ex, "Error in {0} {1}, stacktrace: {2}", context.Request.Method, context.Request.Path, ex.ToString());
					if (ex.InnerException != null) {
						_logger.LogError(ex, "-> inner error {0}", context.Request.Method, context.Request.Path, ex.InnerException.ToString());						
					}
				}

				await HandleExceptionAsync(context, statusCode, ex.GetBaseException());
			}
		}

		private static Task HandleExceptionAsync(HttpContext context, HttpStatusCode statusCode, Exception exception)
		{
			context.Response.ContentType = "application/json";
			context.Response.StatusCode = (int)statusCode;
			var response = new ErrorInfo { ErrorCode = statusCode, ErrorMessage = exception.Message };
#if DEBUG
			response.StackTrace = exception.StackTrace;
#endif
			return context.Response.WriteAsync(JsonConvert.SerializeObject(response));
		}
	}
}
