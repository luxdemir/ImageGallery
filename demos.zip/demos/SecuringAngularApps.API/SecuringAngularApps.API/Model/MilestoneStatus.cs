﻿using System;

namespace SecuringAngularApps.API.Model
{
    public class MilestoneStatus
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
