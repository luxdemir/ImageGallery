export class SimpleClaim {
  type: string;
  value: string;
}