export class Milestone {
    id: number;
    name: string;
    projectId: number;
    milestoneStatusId: number;
}