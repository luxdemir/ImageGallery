export class MilestoneStatus {
    id: number;
    name: string;
}